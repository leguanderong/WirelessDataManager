# WirelessDataManager / 无线文件管理器 v0.3

一个面向 Android 11–16 的中文文件管理器。普通目录不依赖 ADB；只有访问 `Android/data` / `Android/obb` 时才按需使用应用内置的无线 ADB 配对能力。

## v0.3 主要变化

- 全新单窗手机布局：主页快捷入口 + 文件列表 + 底部导航，适合竖屏操作。
- 未进行无线调试授权时，仍然是完整的普通文件管理器。
- 普通文件通过 Android 的“管理所有文件”权限直接操作，不依赖开发者选项。
- `Android/data` / `Android/obb` 单独显示锁定/解锁状态。
- 内置无线调试配对、自动重连和手动连接端口。
- 修复 v0.2 的 `Stream closed.`：对 libadb 一次性 shell 正常关闭做 EOF 兼容。
- 所有 ADB shell 命令串行执行，避免多任务抢同一 ADB 通道。
- 搜索、排序、长按批量选择、复制、移动、删除、重命名、新建文件夹、收藏路径。
- 复制/移动使用底部“剪贴板”条，进入目标目录后点“粘贴”。
- 操作进度与更明确的权限/断连错误提示。
- Material 3 + Android 动态配色。

## 权限逻辑

### 普通文件
Android 11+ 使用系统 `MANAGE_EXTERNAL_STORAGE`（管理所有文件）权限。该权限不需要 Root、不需要 Shizuku，也不需要开发者选项。

### Android/data
普通“所有文件访问”仍不能直接解锁其它应用的 `Android/data`。v0.3 只有在无线 ADB 连接有效时，才将这类路径的文件命令交给 shell 身份执行。

关闭无线调试或开发者选项后，ADB 连接可能立即失效，Data 会重新锁定；已配对的密钥保存在应用私有目录中，重新开启无线调试后可尝试“已有配对 · 自动重连”。手机重启后也需要重新建立 ADB 连接。

## 构建

仓库中的 `.github/workflows/build-apk.yml` 会自动选择仓库根目录里版本号最高的：

`WirelessDataManager-v*-src*.zip`

然后编译 `app-debug.apk` 并上传为 GitHub Actions Artifact。
