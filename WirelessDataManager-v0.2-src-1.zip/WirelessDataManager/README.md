# WirelessDataManager / 无线文件管理器

Android 11–16 文件管理器实验项目：在应用内通过 Android 无线调试完成 ADB 配对并使用 `shell` 身份执行文件操作，不依赖 Shizuku，也不需要 Root 或电脑参与日常使用。

## v0.2.0

- 中文双窗口文件管理器，左右窗口可独立浏览。
- 首页右窗直接打开 `/sdcard/Android/data`。
- 文件类型图标和文件大小显示。
- 当前窗口实时搜索。
- 名称 / 大小 / 类型排序，可切换升降序。
- 长按批量选择，多文件复制、剪切、删除。
- 粘贴时显示近似复制进度；目录进度通过目标目录大小轮询估算。
- 收藏路径、打开收藏、删除收藏。
- 底部导航：内部存储、Android/data、收藏、排序、更多。
- 内置无线 ADB 配对：配对端口 + 6 位配对码；配对密钥保存在应用私有数据中。
- 支持自动发现连接端口，也可手动填写。
- 失败时直接显示 shell / 权限错误，方便判断 Android 16 ROM 是否继续限制目标路径。

## 使用

1. 临时打开开发者选项和“无线调试”。
2. 系统中点“使用配对码配对设备”。
3. 应用中点“授权/连接”，填写配对端口和 6 位配对码。
4. 授权后左右窗口即可通过 ADB shell 浏览和操作文件。
5. 如果自动连接失败，在“连接端口”中填写无线调试主页面显示的端口。

> Android 16 的厂商 ROM / 安全补丁可能继续对 `Android/data` 实施额外 FUSE/SELinux 限制。如果 shell 本身收到 `Permission denied`，应用会原样提示，此时不是普通文件管理器 UI 权限问题。

## 构建

仓库包含 GitHub Actions 工作流。每次推送到 `main` / `master` 会执行：

```bash
gradle :app:assembleDebug
```

构建产物 Artifact 名称：`WirelessDataManager-debug`。

## 依赖

- `MuntashirAkon/libadb-android`
- `MuntashirAkon/sun-security-android`
- `LSPosed/AndroidHiddenApiBypass`
