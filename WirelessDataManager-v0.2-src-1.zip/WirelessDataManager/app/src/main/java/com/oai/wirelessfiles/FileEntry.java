package com.oai.wirelessfiles;

public class FileEntry {
    public final String name;
    public final boolean directory;
    public final long size;

    public FileEntry(String name, boolean directory, long size) {
        this.name = name;
        this.directory = directory;
        this.size = size;
    }
}
