package com.oai.wirelessfiles;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class FileListAdapter extends BaseAdapter {
    private final LayoutInflater inflater;
    private List<FileEntry> items = Collections.emptyList();
    private final Set<String> selected = new HashSet<>();

    public FileListAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public void submit(List<FileEntry> next) {
        items = next;
        selected.retainAll(names(next));
        notifyDataSetChanged();
    }

    public FileEntry getEntry(int position) { return items.get(position); }

    public void toggle(String name) {
        if (!selected.add(name)) selected.remove(name);
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selected.clear();
        notifyDataSetChanged();
    }

    public Set<String> selectedNames() { return new HashSet<>(selected); }
    public int selectedCount() { return selected.size(); }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_file, parent, false);
            h = new Holder();
            h.check = convertView.findViewById(R.id.rowCheck);
            h.icon = convertView.findViewById(R.id.rowIcon);
            h.name = convertView.findViewById(R.id.rowName);
            h.meta = convertView.findViewById(R.id.rowMeta);
            convertView.setTag(h);
        } else h = (Holder) convertView.getTag();

        FileEntry e = items.get(position);
        h.check.setChecked(selected.contains(e.name));
        h.icon.setText(iconFor(e));
        h.name.setText(e.name);
        h.name.setTypeface(null, e.directory ? Typeface.BOLD : Typeface.NORMAL);
        h.meta.setText(e.directory ? "文件夹" : human(e.size));
        return convertView;
    }

    private static Set<String> names(List<FileEntry> list) {
        Set<String> s = new HashSet<>();
        for (FileEntry e : list) s.add(e.name);
        return s;
    }

    private static String iconFor(FileEntry e) {
        if (e.directory) return "📁";
        String n = e.name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".apk")) return "📦";
        if (n.endsWith(".zip") || n.endsWith(".7z") || n.endsWith(".rar") || n.endsWith(".tar") || n.endsWith(".gz")) return "🗜️";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".gif")) return "🖼️";
        if (n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".mov")) return "🎬";
        if (n.endsWith(".mp3") || n.endsWith(".flac") || n.endsWith(".wav") || n.endsWith(".m4a")) return "🎵";
        if (n.endsWith(".txt") || n.endsWith(".log") || n.endsWith(".json") || n.endsWith(".xml") || n.endsWith(".ini") || n.endsWith(".cfg") || n.endsWith(".sh")) return "📝";
        return "📄";
    }

    private static String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024L * 1024) return String.format(Locale.getDefault(), "%.1f KB", n / 1024.0);
        if (n < 1024L * 1024 * 1024) return String.format(Locale.getDefault(), "%.1f MB", n / 1048576.0);
        return String.format(Locale.getDefault(), "%.1f GB", n / 1073741824.0);
    }

    private static class Holder {
        CheckBox check;
        TextView icon, name, meta;
    }
}
