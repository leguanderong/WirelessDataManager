package com.oai.wirelessfiles;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

public final class ShellExecutor {
    private ShellExecutor() {}

    public static byte[] runBytes(Context context, String command) throws Exception {
        AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(context);
        if (!manager.isConnected()) throw new IllegalStateException("ADB 尚未连接");
        try (AdbStream stream = manager.openStream("shell:" + command);
             InputStream in = stream.openInputStream();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    public static String run(Context context, String command) throws Exception {
        return new String(runBytes(context, command), StandardCharsets.UTF_8);
    }

    public static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
