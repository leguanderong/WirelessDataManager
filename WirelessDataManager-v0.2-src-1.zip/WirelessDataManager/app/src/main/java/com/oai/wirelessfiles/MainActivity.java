package com.oai.wirelessfiles;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.android.AndroidUtils;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "wdm_prefs";
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private final List<String> clipboard = new ArrayList<>();
    private boolean clipboardMove;

    private TextView status, clipboardView, activeLabel;
    private EditText searchBox;
    private FilePane left, right, active;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        status = findViewById(R.id.status);
        clipboardView = findViewById(R.id.clipboard);
        activeLabel = findViewById(R.id.activeLabel);
        searchBox = findViewById(R.id.searchBox);

        left = new FilePane("左窗", findViewById(R.id.leftPane), findViewById(R.id.leftPath), findViewById(R.id.leftList), "/sdcard");
        right = new FilePane("右窗", findViewById(R.id.rightPane), findViewById(R.id.rightPath), findViewById(R.id.rightList), "/sdcard/Android/data");
        setActive(left);

        findViewById(R.id.openDebug).setOnClickListener(v -> openDeveloperSettings());
        findViewById(R.id.pairConnect).setOnClickListener(v -> showPairDialog());
        findViewById(R.id.disconnect).setOnClickListener(v -> disconnect());
        findViewById(R.id.homeNav).setOnClickListener(v -> active.openPath("/sdcard"));
        findViewById(R.id.dataNav).setOnClickListener(v -> active.openPath("/sdcard/Android/data"));
        findViewById(R.id.favoritesNav).setOnClickListener(v -> showFavorites());
        findViewById(R.id.sortNav).setOnClickListener(v -> showSortDialog());
        findViewById(R.id.moreNav).setOnClickListener(v -> showMoreMenu());

        findViewById(R.id.copySelected).setOnClickListener(v -> copySelected(false));
        findViewById(R.id.cutSelected).setOnClickListener(v -> copySelected(true));
        findViewById(R.id.deleteSelected).setOnClickListener(v -> deleteSelected());
        findViewById(R.id.clearSelected).setOnClickListener(v -> clearSelections());
        findViewById(R.id.paste).setOnClickListener(v -> pasteIntoActive());

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { if (active != null) active.applyView(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        autoConnect();
    }

    private final class FilePane {
        final String title;
        final View root;
        final TextView pathView;
        final ListView listView;
        final FileListAdapter adapter;
        final List<FileEntry> all = new ArrayList<>();
        String path;
        int sortMode = 0;
        boolean descending = false;

        FilePane(String title, View root, TextView pathView, ListView listView, String initialPath) {
            this.title = title;
            this.root = root;
            this.pathView = pathView;
            this.listView = listView;
            this.path = initialPath;
            adapter = new FileListAdapter(MainActivity.this);
            listView.setAdapter(adapter);
            root.setOnClickListener(v -> setActive(this));
            pathView.setOnClickListener(v -> setActive(this));
            pathView.setOnLongClickListener(v -> { showPathActions(this); return true; });

            listView.setOnItemClickListener((parent, view, position, id) -> {
                setActive(this);
                FileEntry e = adapter.getEntry(position);
                if (adapter.selectedCount() > 0) {
                    adapter.toggle(e.name);
                    updateSelectionStatus();
                    return;
                }
                String full = join(path, e.name);
                if (e.directory) openPath(full);
                else showItemActions(this, e, full);
            });
            listView.setOnItemLongClickListener((parent, view, position, id) -> {
                setActive(this);
                FileEntry e = adapter.getEntry(position);
                adapter.toggle(e.name);
                updateSelectionStatus();
                return true;
            });
        }

        void openPath(String p) {
            path = normalize(p);
            refresh();
        }

        void up() {
            if ("/".equals(path)) return;
            int i = path.lastIndexOf('/');
            openPath(i <= 0 ? "/" : path.substring(0, i));
        }

        void refresh() {
            pathView.setText(path);
            io.submit(() -> {
                try {
                    List<FileEntry> got = listDir(path);
                    runOnUiThread(() -> {
                        all.clear();
                        all.addAll(got);
                        applyView();
                    });
                } catch (Throwable e) {
                    setStatus(title + "读取失败：" + shortError(e));
                }
            });
        }

        void applyView() {
            String q = this == active ? searchBox.getText().toString().trim().toLowerCase(Locale.ROOT) : "";
            List<FileEntry> shown = new ArrayList<>();
            for (FileEntry e : all) {
                if (q.isEmpty() || e.name.toLowerCase(Locale.ROOT).contains(q)) shown.add(e);
            }
            Comparator<FileEntry> cmp;
            if (sortMode == 1) cmp = Comparator.comparingLong(e -> e.size);
            else if (sortMode == 2) cmp = Comparator.comparing((FileEntry e) -> !e.directory).thenComparing(e -> ext(e.name));
            else cmp = Comparator.comparing(e -> e.name.toLowerCase(Locale.ROOT));
            cmp = Comparator.comparing((FileEntry e) -> !e.directory).thenComparing(cmp);
            if (descending) cmp = cmp.reversed();
            shown.sort(cmp);
            adapter.submit(shown);
            pathView.setText(path);
        }

        List<String> selectedFullPaths() {
            List<String> out = new ArrayList<>();
            for (String n : adapter.selectedNames()) out.add(join(path, n));
            return out;
        }
    }

    private void setActive(FilePane pane) {
        active = pane;
        left.root.setBackgroundColor(left == pane ? 0x166750A4 : Color.TRANSPARENT);
        right.root.setBackgroundColor(right == pane ? 0x166750A4 : Color.TRANSPARENT);
        activeLabel.setText("当前操作：" + pane.title + "  ·  " + pane.path);
        searchBox.setText("");
        pane.applyView();
    }

    private void openDeveloperSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void showPairDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        box.setPadding(pad, pad, pad, 0);
        EditText pairPort = numberInput("配对端口，例如 37123");
        EditText code = numberInput("6 位配对码");
        EditText connectPort = numberInput("连接端口（可留空，自动发现）");
        box.addView(pairPort); box.addView(code); box.addView(connectPort);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("无线调试授权")
                .setMessage("先在系统“无线调试 → 使用配对码配对设备”中查看配对端口和 6 位配对码。")
                .setView(box).setNegativeButton("取消", null).setPositiveButton("开始", null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p = pairPort.getText().toString().trim();
            String c = code.getText().toString().trim();
            String cp = connectPort.getText().toString().trim();
            if (p.isEmpty() || c.length() != 6) { toast("请输入配对端口和 6 位配对码"); return; }
            dialog.dismiss();
            pairAndConnect(Integer.parseInt(p), c, cp.isEmpty() ? null : Integer.parseInt(cp));
        }));
        dialog.show();
    }

    private EditText numberInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private void pairAndConnect(int pairPort, String code, Integer connectPort) {
        setStatus("正在配对…");
        io.submit(() -> {
            try {
                AbsAdbConnectionManager m = AdbConnectionManager.getInstance(this);
                if (m.isConnected()) m.disconnect();
                String host = AndroidUtils.getHostIpAddress(this);
                if (!m.pair(host, pairPort, code)) throw new IllegalStateException("配对返回失败");
                setStatus("配对成功，正在连接…");
                boolean connected = connectPort != null ? m.connect(host, connectPort) : m.autoConnect(this, 8000);
                if (!connected && !m.isConnected()) throw new IllegalStateException("连接失败，请填写无线调试主页面显示的连接端口再试");
                onConnected();
            } catch (Throwable e) { setStatus("授权失败：" + shortError(e)); }
        });
    }

    private void autoConnect() {
        setStatus("正在尝试恢复无线调试连接…");
        io.submit(() -> {
            try {
                AbsAdbConnectionManager m = AdbConnectionManager.getInstance(this);
                if (m.isConnected() || m.autoConnect(this, 3500)) onConnected();
                else setStatus("未连接；需要时点击“授权 / 连接”");
            } catch (Throwable e) { setStatus("未连接；需要时点击“授权 / 连接”"); }
        });
    }

    private void onConnected() {
        try {
            String who = ShellExecutor.run(this, "id; printf '\\n'; getprop ro.build.version.release");
            setStatus("已连接 shell · " + who.replace('\n', ' ').trim());
        } catch (Throwable e) { setStatus("已连接，但 shell 测试失败：" + shortError(e)); }
        left.refresh();
        right.refresh();
    }

    private void disconnect() {
        io.submit(() -> {
            try { AdbConnectionManager.getInstance(this).disconnect(); } catch (Throwable ignored) {}
            setStatus("已断开无线调试连接");
        });
    }

    private List<FileEntry> listDir(String p) throws Exception {
        String qp = ShellExecutor.q(p);
        String cmd = "p=" + qp + "; [ -d \"$p\" ] || { echo __NOT_DIR__; exit 2; }; " +
                "for f in \"$p\"/* \"$p\"/.[!.]* \"$p\"/..?*; do [ -e \"$f\" ] || continue; " +
                "if [ -d \"$f\" ]; then t=D; else t=F; fi; s=$(stat -c %s \"$f\" 2>/dev/null || echo 0); " +
                "n=${f##*/}; printf '%s\\0%s\\0%s\\0' \"$t\" \"$s\" \"$n\"; done";
        byte[] raw = ShellExecutor.runBytes(this, cmd);
        String marker = new String(raw, StandardCharsets.UTF_8);
        if (marker.startsWith("__NOT_DIR__")) throw new IllegalStateException("目录不存在或无权访问");
        List<byte[]> fields = splitNul(raw);
        List<FileEntry> out = new ArrayList<>();
        for (int i = 0; i + 2 < fields.size(); i += 3) {
            String type = new String(fields.get(i), StandardCharsets.UTF_8);
            String size = new String(fields.get(i + 1), StandardCharsets.UTF_8);
            String name = new String(fields.get(i + 2), StandardCharsets.UTF_8);
            long n = 0; try { n = Long.parseLong(size.trim()); } catch (Exception ignored) {}
            out.add(new FileEntry(name, "D".equals(type), n));
        }
        return out;
    }

    private List<byte[]> splitNul(byte[] raw) {
        List<byte[]> out = new ArrayList<>();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        for (byte x : raw) {
            if (x == 0) { out.add(b.toByteArray()); b.reset(); } else b.write(x);
        }
        if (b.size() > 0) out.add(b.toByteArray());
        return out;
    }

    private void showItemActions(FilePane pane, FileEntry e, String full) {
        String[] actions = e.directory
                ? new String[]{"打开", "复制", "剪切", "收藏此目录", "重命名", "删除"}
                : new String[]{"复制", "剪切", "重命名", "删除"};
        new AlertDialog.Builder(this).setTitle(e.name).setItems(actions, (d, which) -> {
            String action = actions[which];
            if ("打开".equals(action)) pane.openPath(full);
            else if ("复制".equals(action)) setClipboard(Collections.singletonList(full), false);
            else if ("剪切".equals(action)) setClipboard(Collections.singletonList(full), true);
            else if ("收藏此目录".equals(action)) addFavorite(full);
            else if ("重命名".equals(action)) rename(pane, full, e.name);
            else if ("删除".equals(action)) deletePaths(Collections.singletonList(full));
        }).show();
    }

    private void showPathActions(FilePane pane) {
        new AlertDialog.Builder(this).setTitle(pane.path)
                .setItems(new String[]{"上一级", "刷新", "收藏当前路径", "复制路径"}, (d, w) -> {
                    if (w == 0) pane.up();
                    else if (w == 1) pane.refresh();
                    else if (w == 2) addFavorite(pane.path);
                    else if (w == 3) {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", pane.path));
                        toast("路径已复制");
                    }
                }).show();
    }

    private void copySelected(boolean move) {
        List<String> paths = new ArrayList<>();
        paths.addAll(left.selectedFullPaths());
        paths.addAll(right.selectedFullPaths());
        if (paths.isEmpty()) { toast("请先长按选择文件"); return; }
        setClipboard(paths, move);
        clearSelections();
    }

    private void setClipboard(List<String> paths, boolean move) {
        clipboard.clear();
        clipboard.addAll(paths);
        clipboardMove = move;
        clipboardView.setText("剪贴板：" + (move ? "剪切 " : "复制 ") + paths.size() + " 项");
    }

    private void pasteIntoActive() {
        if (clipboard.isEmpty()) { toast("剪贴板为空"); return; }
        final List<String> sources = new ArrayList<>(clipboard);
        final String destinationDir = active.path;
        showCopyProgress(sources, destinationDir, clipboardMove);
    }

    private void showCopyProgress(List<String> sources, String destinationDir, boolean move) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(8));
        TextView message = new TextView(this);
        message.setText("准备中…");
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgress(0);
        box.addView(message, new LinearLayout.LayoutParams(-1, -2));
        box.addView(bar, new LinearLayout.LayoutParams(-1, dp(24)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(move ? "正在移动" : "正在复制")
                .setView(box).setNegativeButton("后台继续", null).create();
        dialog.show();

        io.submit(() -> {
            try {
                long totalKb = 0;
                List<Long> sizes = new ArrayList<>();
                for (String src : sources) {
                    long s = sizeKb(src);
                    sizes.add(s);
                    totalKb += Math.max(1, s);
                }
                long completedKb = 0;
                for (int i = 0; i < sources.size(); i++) {
                    String src = sources.get(i);
                    long itemKb = Math.max(1, sizes.get(i));
                    String name = src.substring(src.lastIndexOf('/') + 1);
                    String dest = join(destinationDir, name);
                    long baseCompleted = completedKb;
                    AtomicBoolean done = new AtomicBoolean(false);
                    Thread monitor = new Thread(() -> {
                        while (!done.get()) {
                            try {
                                long copied = Math.min(itemKb, sizeKb(dest));
                                long now = baseCompleted + copied;
                                int p = (int) Math.min(1000, (now * 1000L) / Math.max(1L, finalTotal(sizes)));
                                runOnUiThread(() -> { bar.setProgress(p); message.setText(name + "  ·  " + (p / 10.0) + "%"); });
                                Thread.sleep(450);
                            } catch (Throwable ignored) {
                                try { Thread.sleep(500); } catch (InterruptedException e) { return; }
                            }
                        }
                    }, "copy-progress");
                    monitor.start();
                    String cmd = move ? "mv -- " + ShellExecutor.q(src) + " " + ShellExecutor.q(dest)
                            : "cp -a -- " + ShellExecutor.q(src) + " " + ShellExecutor.q(dest);
                    String out = ShellExecutor.run(this, cmd + "; rc=$?; printf '\\n__RC__%s' \"$rc\"");
                    done.set(true);
                    int rc = parseRc(out);
                    if (rc != 0) throw new IllegalStateException(stripRc(out));
                    completedKb += itemKb;
                }
                if (move) {
                    clipboard.clear();
                    clipboardMove = false;
                }
                runOnUiThread(() -> {
                    bar.setProgress(1000);
                    message.setText(move ? "移动完成" : "复制完成");
                    clipboardView.setText(clipboard.isEmpty() ? "剪贴板：空" : clipboardView.getText());
                    dialog.dismiss();
                    left.refresh(); right.refresh();
                    toast(move ? "移动完成" : "复制完成");
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    dialog.dismiss();
                    new AlertDialog.Builder(this).setTitle("操作失败").setMessage(shortError(e)).setPositiveButton("确定", null).show();
                });
            }
        });
    }

    private long finalTotal(List<Long> sizes) {
        long t = 0; for (long s : sizes) t += Math.max(1, s); return Math.max(1, t);
    }

    private long sizeKb(String path) {
        try {
            String out = ShellExecutor.run(this, "du -sk -- " + ShellExecutor.q(path) + " 2>/dev/null | head -n 1 | cut -f1").trim();
            if (out.isEmpty()) return 0;
            return Long.parseLong(out.split("\\s+")[0]);
        } catch (Throwable ignored) { return 0; }
    }

    private void deleteSelected() {
        List<String> paths = new ArrayList<>();
        paths.addAll(left.selectedFullPaths());
        paths.addAll(right.selectedFullPaths());
        if (paths.isEmpty()) { toast("没有选择项目"); return; }
        deletePaths(paths);
    }

    private void deletePaths(List<String> paths) {
        new AlertDialog.Builder(this).setTitle("确认删除？")
                .setMessage("将删除 " + paths.size() + " 项，此操作不可撤销。")
                .setNegativeButton("取消", null).setPositiveButton("删除", (d, w) -> {
                    StringBuilder cmd = new StringBuilder();
                    for (String p : paths) cmd.append("rm -rf -- ").append(ShellExecutor.q(p)).append("; ");
                    runMutation(cmd.toString(), "删除完成", this::clearSelections);
                }).show();
    }

    private void clearSelections() {
        runOnUiThread(() -> {
            left.adapter.clearSelection();
            right.adapter.clearSelection();
            updateSelectionStatus();
        });
    }

    private void updateSelectionStatus() {
        int n = left.adapter.selectedCount() + right.adapter.selectedCount();
        activeLabel.setText(n > 0 ? "已选择 " + n + " 项 · 可批量复制/剪切/删除" : "当前操作：" + active.title + "  ·  " + active.path);
    }

    private void rename(FilePane pane, String full, String oldName) {
        EditText input = new EditText(this);
        input.setText(oldName); input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("重命名").setView(input).setNegativeButton("取消", null)
                .setPositiveButton("确定", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty() || name.contains("/")) { toast("名称无效"); return; }
                    runMutation("mv -- " + ShellExecutor.q(full) + " " + ShellExecutor.q(join(pane.path, name)), "重命名完成", null);
                }).show();
    }

    private void mkdir() {
        EditText input = new EditText(this); input.setHint("文件夹名称");
        new AlertDialog.Builder(this).setTitle("在 " + active.title + " 新建文件夹").setView(input).setNegativeButton("取消", null)
                .setPositiveButton("创建", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty() || name.contains("/")) { toast("名称无效"); return; }
                    runMutation("mkdir -p -- " + ShellExecutor.q(join(active.path, name)), "创建完成", null);
                }).show();
    }

    private void showSortDialog() {
        String[] modes = {"名称", "大小", "类型", active.descending ? "切换为升序" : "切换为降序"};
        new AlertDialog.Builder(this).setTitle("排序 · " + active.title).setItems(modes, (d, w) -> {
            if (w <= 2) active.sortMode = w;
            else active.descending = !active.descending;
            active.applyView();
        }).show();
    }

    private void showFavorites() {
        Set<String> set = new LinkedHashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
        List<String> favs = new ArrayList<>(set);
        String[] items = new String[favs.size() + 1];
        items[0] = "★ 收藏当前路径：" + active.path;
        for (int i = 0; i < favs.size(); i++) items[i + 1] = favs.get(i);
        new AlertDialog.Builder(this).setTitle("收藏路径").setItems(items, (d, w) -> {
            if (w == 0) addFavorite(active.path);
            else active.openPath(favs.get(w - 1));
        }).setNeutralButton("管理", (d, w) -> manageFavorites()).setNegativeButton("关闭", null).show();
    }

    private void addFavorite(String path) {
        Set<String> set = new HashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
        set.add(path);
        prefs.edit().putStringSet("favorites", set).apply();
        toast("已收藏");
    }

    private void manageFavorites() {
        List<String> favs = new ArrayList<>(prefs.getStringSet("favorites", Collections.emptySet()));
        if (favs.isEmpty()) { toast("暂无收藏"); return; }
        boolean[] checked = new boolean[favs.size()];
        new AlertDialog.Builder(this).setTitle("删除收藏").setMultiChoiceItems(favs.toArray(new String[0]), checked, null)
                .setNegativeButton("取消", null).setPositiveButton("删除所选", (d, w) -> {
                    Set<String> set = new HashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
                    for (int i = 0; i < checked.length; i++) if (checked[i]) set.remove(favs.get(i));
                    prefs.edit().putStringSet("favorites", set).apply();
                }).show();
    }

    private void showMoreMenu() {
        String[] menu = {"上一级", "刷新双窗", "新建文件夹", "交换左右路径", "清空搜索", "断开无线调试"};
        new AlertDialog.Builder(this).setTitle("更多").setItems(menu, (d, w) -> {
            if (w == 0) active.up();
            else if (w == 1) { left.refresh(); right.refresh(); }
            else if (w == 2) mkdir();
            else if (w == 3) {
                String a = left.path; left.path = right.path; right.path = a; left.refresh(); right.refresh();
            } else if (w == 4) searchBox.setText("");
            else disconnect();
        }).show();
    }

    private void runMutation(String command, String ok, Runnable after) {
        setStatus("正在执行…");
        io.submit(() -> {
            try {
                String out = ShellExecutor.run(this, command + "; rc=$?; printf '\\n__RC__%s' \"$rc\"");
                int rc = parseRc(out);
                if (rc != 0) throw new IllegalStateException(stripRc(out));
                if (after != null) after.run();
                setStatus(ok);
                left.refresh(); right.refresh();
            } catch (Throwable e) { setStatus("操作失败：" + shortError(e)); }
        });
    }

    private static int parseRc(String out) {
        int k = out.lastIndexOf("__RC__");
        if (k < 0) return 0;
        try { return Integer.parseInt(out.substring(k + 6).trim()); } catch (Exception e) { return 1; }
    }

    private static String stripRc(String out) {
        int k = out.lastIndexOf("__RC__");
        String s = k >= 0 ? out.substring(0, k).trim() : out.trim();
        return s.isEmpty() ? "Shell 操作失败" : s;
    }

    private static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static String join(String a, String b) {
        if ("/".equals(a)) return "/" + b;
        return a.endsWith("/") ? a + b : a + "/" + b;
    }

    private static String normalize(String p) {
        if (p == null || p.isEmpty()) return "/";
        while (p.length() > 1 && p.endsWith("/")) p = p.substring(0, p.length() - 1);
        return p;
    }

    private String shortError(Throwable e) {
        Throwable t = e;
        while (t.getCause() != null) t = t.getCause();
        String m = t.getMessage();
        return (m == null || m.trim().isEmpty()) ? t.getClass().getSimpleName() : m;
    }

    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private void setStatus(String s) { runOnUiThread(() -> status.setText(s)); }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
