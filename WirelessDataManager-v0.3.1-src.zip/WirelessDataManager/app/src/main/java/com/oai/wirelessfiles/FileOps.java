package com.oai.wirelessfiles;

import android.content.Context;
import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public final class FileOps {
    private FileOps() {}

    public interface ProgressCallback {
        void onProgress(int done, int total, String currentName);
    }

    public static boolean hasAllFilesAccess() {
        return android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
    }

    public static boolean isRestricted(String path) {
        String p = normalize(path);
        return p.equals("/sdcard/Android/data") || p.startsWith("/sdcard/Android/data/")
                || p.equals("/sdcard/Android/obb") || p.startsWith("/sdcard/Android/obb/")
                || p.equals("/storage/emulated/0/Android/data") || p.startsWith("/storage/emulated/0/Android/data/")
                || p.equals("/storage/emulated/0/Android/obb") || p.startsWith("/storage/emulated/0/Android/obb/");
    }

    public static List<FileEntry> list(Context context, String path, boolean showHidden) throws Exception {
        path = normalize(path);
        if (isRestricted(path)) return listShell(context, path, showHidden);
        return listLocal(path, showHidden);
    }

    private static List<FileEntry> listLocal(String path, boolean showHidden) throws IOException {
        File dir = new File(path);
        if (!dir.isDirectory()) throw new IOException("目录不存在或没有访问权限");
        File[] files = dir.listFiles();
        if (files == null) throw new IOException("无法读取目录，请授予“所有文件访问权限”");
        List<FileEntry> out = new ArrayList<>();
        for (File file : files) {
            if (!showHidden && file.getName().startsWith(".")) continue;
            out.add(new FileEntry(file.getName(), file.getAbsolutePath(), file.isDirectory(), file.isDirectory() ? 0 : file.length(), file.lastModified()));
        }
        return out;
    }

    private static List<FileEntry> listShell(Context context, String path, boolean showHidden) throws Exception {
        if (!ShellExecutor.isConnected(context)) throw new SecurityException("需要无线调试授权");
        String hidden = showHidden ? "" : "[ \"${n#'.'}\" = \"$n\" ] || continue; ";
        String q = ShellExecutor.q(path);
        String cmd = "p=" + q + "; [ -d \"$p\" ] || { echo '目录不存在或没有访问权限' >&2; exit 2; }; " +
                "for f in \"$p\"/* \"$p\"/.[!.]* \"$p\"/..?*; do [ -e \"$f\" ] || continue; n=${f##*/}; " + hidden +
                "if [ -d \"$f\" ]; then t=D; s=0; else t=F; s=$(stat -c %s \"$f\" 2>/dev/null || echo 0); fi; " +
                "m=$(stat -c %Y \"$f\" 2>/dev/null || echo 0); printf '%s\\0%s\\0%s\\0%s\\0' \"$t\" \"$s\" \"$m\" \"$n\"; done";
        byte[] raw = ShellExecutor.runBytes(context, cmd);
        List<byte[]> fields = splitNul(raw);
        List<FileEntry> out = new ArrayList<>();
        for (int i = 0; i + 3 < fields.size(); i += 4) {
            String type = str(fields.get(i));
            long size = number(str(fields.get(i + 1)));
            long modifiedSeconds = number(str(fields.get(i + 2)));
            String name = str(fields.get(i + 3));
            out.add(new FileEntry(name, join(path, name), "D".equals(type), size, modifiedSeconds * 1000L));
        }
        return out;
    }

    public static void mkdir(Context context, String parent, String name) throws Exception {
        String target = join(parent, name);
        if (isRestricted(target)) {
            ShellExecutor.runBytes(context, "mkdir -p " + ShellExecutor.q(target));
        } else if (!new File(target).mkdirs() && !new File(target).isDirectory()) {
            throw new IOException("创建文件夹失败");
        }
    }

    public static void rename(Context context, String source, String newName) throws Exception {
        String parent = parent(source);
        String dest = join(parent, newName);
        moveOne(context, source, dest);
    }

    public static void delete(Context context, List<String> paths, ProgressCallback callback) throws Exception {
        int total = paths.size();
        for (int i = 0; i < total; i++) {
            String path = paths.get(i);
            if (callback != null) callback.onProgress(i, total, name(path));
            if (isRestricted(path)) ShellExecutor.runBytes(context, "rm -rf " + ShellExecutor.q(path));
            else deleteLocal(new File(path));
        }
        if (callback != null) callback.onProgress(total, total, "");
    }

    public static void copy(Context context, List<String> sources, String destDir, boolean move, ProgressCallback callback) throws Exception {
        int total = sources.size();
        for (int i = 0; i < total; i++) {
            String src = sources.get(i);
            String dest = join(destDir, name(src));
            if (callback != null) callback.onProgress(i, total, name(src));
            if (move) moveOne(context, src, dest);
            else copyOne(context, src, dest);
        }
        if (callback != null) callback.onProgress(total, total, "");
    }

    private static void copyOne(Context context, String src, String dest) throws Exception {
        if (normalize(src).equals(normalize(dest))) throw new IOException("源文件与目标位置相同");
        if (isRestricted(src) || isRestricted(dest)) {
            if (!ShellExecutor.isConnected(context)) throw new SecurityException("需要无线调试授权");
            ShellExecutor.runBytes(context, "cp -a " + ShellExecutor.q(src) + " " + ShellExecutor.q(dest));
            return;
        }
        copyLocal(new File(src), new File(dest));
    }

    private static void moveOne(Context context, String src, String dest) throws Exception {
        if (normalize(src).equals(normalize(dest))) throw new IOException("源文件与目标位置相同");
        if (isRestricted(src) || isRestricted(dest)) {
            if (!ShellExecutor.isConnected(context)) throw new SecurityException("需要无线调试授权");
            ShellExecutor.runBytes(context, "mv " + ShellExecutor.q(src) + " " + ShellExecutor.q(dest));
            return;
        }
        File from = new File(src), to = new File(dest);
        File parent = to.getParentFile();
        if (parent != null) parent.mkdirs();
        try {
            Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Throwable e) {
            copyLocal(from, to);
            deleteLocal(from);
        }
    }

    private static void copyLocal(File src, File dest) throws IOException {
        if (src.isDirectory()) {
            if (!dest.exists() && !dest.mkdirs()) throw new IOException("无法创建目录：" + dest.getName());
            File[] children = src.listFiles();
            if (children == null) throw new IOException("无法读取：" + src.getName());
            for (File child : children) copyLocal(child, new File(dest, child.getName()));
        } else {
            File parent = dest.getParentFile();
            if (parent != null) parent.mkdirs();
            try (FileInputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
            }
            dest.setLastModified(src.lastModified());
        }
    }

    private static void deleteLocal(File file) throws IOException {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteLocal(child);
        }
        if (file.exists() && !file.delete()) throw new IOException("删除失败：" + file.getName());
    }

    private static List<byte[]> splitNul(byte[] raw) {
        List<byte[]> out = new ArrayList<>();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        for (byte x : raw) {
            if (x == 0) { out.add(b.toByteArray()); b.reset(); }
            else b.write(x);
        }
        if (b.size() > 0) out.add(b.toByteArray());
        return out;
    }

    private static String str(byte[] b) { return new String(b, StandardCharsets.UTF_8); }
    private static long number(String s) { try { return Long.parseLong(s.trim()); } catch (Throwable ignored) { return 0; } }

    public static String normalize(String path) {
        if (path == null || path.trim().isEmpty()) return "/sdcard";
        String p = path.trim().replaceAll("/+", "/");
        if (p.length() > 1 && p.endsWith("/")) p = p.substring(0, p.length() - 1);
        return p;
    }
    public static String join(String parent, String child) { return normalize(parent) + (normalize(parent).equals("/") ? "" : "/") + child; }
    public static String parent(String path) {
        String p = normalize(path);
        int i = p.lastIndexOf('/');
        if (i <= 0) return "/";
        return p.substring(0, i);
    }
    public static String name(String path) {
        String p = normalize(path);
        int i = p.lastIndexOf('/');
        return i < 0 ? p : p.substring(i + 1);
    }
}
