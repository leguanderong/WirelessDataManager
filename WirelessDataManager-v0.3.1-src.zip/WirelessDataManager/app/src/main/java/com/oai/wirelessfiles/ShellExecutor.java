package com.oai.wirelessfiles;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

/** Serialized, one-shot ADB shell executor. */
public final class ShellExecutor {
    private static final Object LOCK = new Object();
    private static final byte[] MARKER = "\n__WDM_EXIT__".getBytes(StandardCharsets.UTF_8);

    private ShellExecutor() {}

    public static final class Result {
        public final byte[] output;
        public final int exitCode;
        Result(byte[] output, int exitCode) {
            this.output = output;
            this.exitCode = exitCode;
        }
    }

    public static boolean isConnected(Context context) {
        try {
            return AdbConnectionManager.getInstance(context).isConnected();
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static Result execute(Context context, String command) throws Exception {
        synchronized (LOCK) {
            AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(context);
            if (!manager.isConnected()) throw new IllegalStateException("无线调试尚未连接");

            String wrapped = "sh -c " + q(command + "; rc=$?; printf '\\n__WDM_EXIT__%s\\n' \"$rc\"");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (AdbStream stream = manager.openStream("shell:" + wrapped);
                 InputStream in = stream.openInputStream()) {
                byte[] buf = new byte[16 * 1024];
                while (true) {
                    try {
                        int n = in.read(buf);
                        if (n < 0) break;
                        if (n > 0) out.write(buf, 0, n);
                    } catch (IOException e) {
                        // libadb-android may throw "Stream closed." for a normally completed
                        // one-shot shell command after all payload has already been delivered.
                        String m = e.getMessage();
                        if (m != null && m.toLowerCase().contains("stream closed")) break;
                        throw e;
                    }
                }
            }

            byte[] raw = out.toByteArray();
            int marker = lastIndexOf(raw, MARKER);
            if (marker < 0) {
                if (raw.length == 0) throw new IOException("ADB Shell 通道已关闭，请重新连接无线调试");
                return new Result(raw, 0);
            }

            int codeStart = marker + MARKER.length;
            int codeEnd = codeStart;
            while (codeEnd < raw.length && raw[codeEnd] >= '0' && raw[codeEnd] <= '9') codeEnd++;
            int code = 0;
            try {
                code = Integer.parseInt(new String(raw, codeStart, codeEnd - codeStart, StandardCharsets.UTF_8));
            } catch (Throwable ignored) {}

            byte[] clean = new byte[marker];
            System.arraycopy(raw, 0, clean, 0, marker);
            return new Result(clean, code);
        }
    }

    public static byte[] runBytes(Context context, String command) throws Exception {
        Result result = execute(context, command);
        if (result.exitCode != 0) {
            String message = new String(result.output, StandardCharsets.UTF_8).trim();
            if (message.isEmpty()) message = "Shell 命令失败（" + result.exitCode + "）";
            throw new IOException(message);
        }
        return result.output;
    }

    public static String run(Context context, String command) throws Exception {
        return new String(runBytes(context, command), StandardCharsets.UTF_8);
    }

    public static String q(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private static int lastIndexOf(byte[] data, byte[] needle) {
        outer:
        for (int i = data.length - needle.length; i >= 0; i--) {
            for (int j = 0; j < needle.length; j++) {
                if (data[i + j] != needle[j]) continue outer;
            }
            return i;
        }
        return -1;
    }
}
