package com.oai.wirelessfiles;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.android.AndroidUtils;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "wdm_prefs_v3";
    private static final String ROOT = "/sdcard";
    private static final String DATA = "/sdcard/Android/data";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicInteger loadGeneration = new AtomicInteger();
    private final List<FileEntry> allFiles = new ArrayList<>();
    private final List<String> clipboard = new ArrayList<>();

    private SharedPreferences prefs;
    private MaterialToolbar toolbar;
    private BottomNavigationView bottomNav;
    private View homeView, fileView, loading, selectionBar, clipboardBar;
    private TextView emptyView, accessSummary, dataIcon, dataStatus, favoriteCount, pathView, clipboardText;
    private EditText searchBox;
    private FileListAdapter adapter;

    private String currentPath = ROOT;
    private boolean clipboardMove;
    private boolean showHidden;
    private int sortMode; // 0 name, 1 date, 2 size, 3 type
    private boolean sortDescending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showHidden = prefs.getBoolean("show_hidden", false);

        bindViews();
        setupFileList();
        setupActions();
        setupBack();
        showHome();
        refreshAccessState();
        attemptAutoConnect();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAccessState();
        if (fileView.getVisibility() == View.VISIBLE && !FileOps.isRestricted(currentPath)) refreshCurrent();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private void bindViews() {
        toolbar = findViewById(R.id.toolbar);
        bottomNav = findViewById(R.id.bottomNav);
        homeView = findViewById(R.id.homeView);
        fileView = findViewById(R.id.fileView);
        loading = findViewById(R.id.loading);
        emptyView = findViewById(R.id.emptyView);
        selectionBar = findViewById(R.id.selectionBar);
        clipboardBar = findViewById(R.id.clipboardBar);
        accessSummary = findViewById(R.id.accessSummary);
        dataIcon = findViewById(R.id.dataIcon);
        dataStatus = findViewById(R.id.dataStatus);
        favoriteCount = findViewById(R.id.favoriteCount);
        pathView = findViewById(R.id.pathView);
        clipboardText = findViewById(R.id.clipboardText);
        searchBox = findViewById(R.id.searchBox);
    }

    private void setupFileList() {
        RecyclerView list = findViewById(R.id.fileList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FileListAdapter(new FileListAdapter.Listener() {
            @Override public void onClick(FileEntry entry) {
                if (adapter.selectedCount() > 0) {
                    adapter.toggle(entry);
                    updateSelectionUi();
                    return;
                }
                if (entry.directory) openPath(entry.path);
                else if (FileOps.isRestricted(entry.path)) showFileActions(entry);
                else openFile(entry);
            }
            @Override public void onLongClick(FileEntry entry) {
                adapter.toggle(entry);
                updateSelectionUi();
            }
        });
        list.setAdapter(adapter);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilterAndSort(); }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupActions() {
        findViewById(R.id.storageCard).setOnClickListener(v -> openPath(ROOT));
        findViewById(R.id.downloadCard).setOnClickListener(v -> openPath("/sdcard/Download"));
        findViewById(R.id.dataCard).setOnClickListener(v -> {
            if (ShellExecutor.isConnected(this)) openPath(DATA);
            else showUnlockDialog(true);
        });
        findViewById(R.id.favoritesCard).setOnClickListener(v -> showFavorites());
        findViewById(R.id.accessAction).setOnClickListener(v -> openAllFilesSettings());

        findViewById(R.id.upButton).setOnClickListener(v -> goUp());
        findViewById(R.id.refreshButton).setOnClickListener(v -> refreshCurrent());
        pathView.setOnLongClickListener(v -> { showPathMenu(); return true; });

        findViewById(R.id.copyButton).setOnClickListener(v -> setClipboard(false));
        findViewById(R.id.moveButton).setOnClickListener(v -> setClipboard(true));
        findViewById(R.id.deleteButton).setOnClickListener(v -> confirmDeleteSelected());
        findViewById(R.id.moreSelectedButton).setOnClickListener(v -> showSelectedMore());
        findViewById(R.id.cancelSelectButton).setOnClickListener(v -> clearSelection());
        findViewById(R.id.pasteButton).setOnClickListener(v -> pasteClipboard());
        findViewById(R.id.clearClipboardButton).setOnClickListener(v -> clearClipboard());

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.navHome) { showHome(); return true; }
            if (id == R.id.navFiles) { openPath(currentPath == null ? ROOT : currentPath); return true; }
            if (id == R.id.navFavorites) { showFavorites(); return false; }
            if (id == R.id.navSettings) { showSettingsMenu(); return false; }
            return false;
        });

        toolbar.setOnMenuItemClickListener(item -> false);
        toolbar.getMenu().add("新建文件夹").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        toolbar.getMenu().add("排序").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        toolbar.getMenu().add("收藏当前路径").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        toolbar.getMenu().add("无线调试授权").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        toolbar.setOnMenuItemClickListener(item -> {
            String title = String.valueOf(item.getTitle());
            if (title.equals("新建文件夹")) showCreateFolder();
            else if (title.equals("排序")) showSortDialog();
            else if (title.equals("收藏当前路径")) addFavorite(currentPath);
            else if (title.equals("无线调试授权")) showUnlockDialog(false);
            return true;
        });
    }

    private void setupBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (adapter.selectedCount() > 0) { clearSelection(); return; }
                if (fileView.getVisibility() == View.VISIBLE) {
                    if (!ROOT.equals(currentPath) && !"/".equals(currentPath)) goUp();
                    else showHome();
                } else finish();
            }
        });
    }

    private void showHome() {
        loadGeneration.incrementAndGet();
        homeView.setVisibility(View.VISIBLE);
        fileView.setVisibility(View.GONE);
        toolbar.setTitle("无线文件管理器");
        toolbar.setSubtitle("本机文件 · Data 可按需解锁");
        toolbar.getMenu().setGroupVisible(0, false);
        bottomNav.getMenu().findItem(R.id.navHome).setChecked(true);
        refreshAccessState();
    }

    private void showFilesUi() {
        homeView.setVisibility(View.GONE);
        fileView.setVisibility(View.VISIBLE);
        toolbar.setTitle(FileOps.isRestricted(currentPath) ? "Android/data" : "文件");
        toolbar.setSubtitle(FileOps.isRestricted(currentPath) ? "无线调试权限" : "本机权限");
        toolbar.getMenu().setGroupVisible(0, true);
        bottomNav.getMenu().findItem(R.id.navFiles).setChecked(true);
    }

    private void openPath(String path) {
        path = FileOps.normalize(path);
        if (FileOps.isRestricted(path) && !ShellExecutor.isConnected(this)) {
            showUnlockDialog(true);
            return;
        }
        if (!FileOps.isRestricted(path) && !FileOps.hasAllFilesAccess()) {
            showStoragePermissionDialog(path);
            return;
        }
        currentPath = path;
        searchBox.setText("");
        clearSelection();
        showFilesUi();
        refreshCurrent();
    }

    private void refreshCurrent() {
        final int generation = loadGeneration.incrementAndGet();
        pathView.setText(currentPath);
        loading.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
        io.submit(() -> {
            try {
                List<FileEntry> result = FileOps.list(this, currentPath, showHidden);
                runOnUiThread(() -> {
                    if (generation != loadGeneration.get()) return;
                    loading.setVisibility(View.GONE);
                    allFiles.clear();
                    allFiles.addAll(result);
                    applyFilterAndSort();
                    refreshAccessState();
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    if (generation != loadGeneration.get()) return;
                    loading.setVisibility(View.GONE);
                    allFiles.clear();
                    adapter.submit(Collections.emptyList());
                    emptyView.setVisibility(View.VISIBLE);
                    emptyView.setText(readableError(e));
                    if (FileOps.isRestricted(currentPath)) refreshAccessState();
                });
            }
        });
    }

    private void applyFilterAndSort() {
        String q = searchBox.getText() == null ? "" : searchBox.getText().toString().trim().toLowerCase(Locale.ROOT);
        List<FileEntry> shown = new ArrayList<>();
        for (FileEntry entry : allFiles) if (q.isEmpty() || entry.name.toLowerCase(Locale.ROOT).contains(q)) shown.add(entry);

        Comparator<FileEntry> inner;
        if (sortMode == 1) inner = Comparator.comparingLong(e -> e.modified);
        else if (sortMode == 2) inner = Comparator.comparingLong(e -> e.size);
        else if (sortMode == 3) inner = Comparator.comparing(e -> extension(e.name));
        else inner = Comparator.comparing(e -> e.name.toLowerCase(Locale.ROOT));
        Comparator<FileEntry> cmp = Comparator.comparing((FileEntry e) -> !e.directory).thenComparing(inner);
        if (sortDescending) cmp = cmp.reversed();
        shown.sort(cmp);
        adapter.submit(shown);
        emptyView.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        if (shown.isEmpty()) emptyView.setText(q.isEmpty() ? "此文件夹为空" : "没有匹配的文件");
    }

    private void goUp() {
        if (ROOT.equals(currentPath)) { showHome(); return; }
        String parent = FileOps.parent(currentPath);
        if (parent.startsWith("/storage/emulated/0")) parent = parent.replaceFirst("/storage/emulated/0", "/sdcard");
        openPath(parent);
    }

    private void refreshAccessState() {
        boolean local = FileOps.hasAllFilesAccess();
        boolean shell = ShellExecutor.isConnected(this);
        accessSummary.setText((local ? "✓ 普通文件访问已开启" : "○ 需要开启普通文件访问权限") + "\n" +
                (shell ? "✓ Android/data 已通过无线调试解锁" : "○ Android/data 当前为锁定状态"));
        findViewById(R.id.accessAction).setVisibility(local ? View.GONE : View.VISIBLE);
        dataIcon.setText(shell ? "🔓" : "🔒");
        dataStatus.setText(shell ? "已解锁 · 可复制、移动、删除" : "需要无线调试授权 · 不影响其它文件功能");
        favoriteCount.setText(getFavorites().size() + " 个收藏路径");
    }

    private void showStoragePermissionDialog(String pendingPath) {
        new AlertDialog.Builder(this)
                .setTitle("开启文件访问权限")
                .setMessage("作为普通文件管理器，需要系统的“管理所有文件”权限。它不需要 Root，也不需要开发者选项。Android/data 仍会保持锁定，除非你另外进行无线调试授权。")
                .setNegativeButton("取消", null)
                .setPositiveButton("去开启", (d, w) -> openAllFilesSettings())
                .show();
    }

    private void openAllFilesSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Throwable e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    private void showUnlockDialog(boolean openDataAfter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(18);
        box.setPadding(p, dp(8), p, 0);
        MaterialButton openSettings = new MaterialButton(this);
        openSettings.setText("打开无线调试设置");
        openSettings.setOnClickListener(v -> openDeveloperSettings());
        MaterialButton reconnect = new MaterialButton(this);
        reconnect.setText("已有配对 · 尝试自动重连");
        reconnect.setOnClickListener(v -> manualReconnect(openDataAfter));
        EditText pairPort = numberField("配对端口");
        EditText code = numberField("6 位配对码");
        EditText connectPort = numberField("连接端口（可留空自动发现）");
        box.addView(openSettings); box.addView(reconnect); box.addView(pairPort); box.addView(code); box.addView(connectPort);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("解锁 Android/data")
                .setMessage("临时打开“开发者选项 → 无线调试 → 使用配对码配对设备”。配对密钥会保存在本机，下次通常只需重新打开无线调试即可自动连接。")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("配对并连接", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String ps = pairPort.getText().toString().trim();
            String cs = code.getText().toString().trim();
            String cps = connectPort.getText().toString().trim();
            if (ps.isEmpty() || cs.length() != 6) { toast("请输入配对端口和 6 位配对码"); return; }
            int pp;
            Integer cp = null;
            try { pp = Integer.parseInt(ps); if (!cps.isEmpty()) cp = Integer.parseInt(cps); }
            catch (Throwable e) { toast("端口格式不正确"); return; }
            dialog.dismiss();
            pairAndConnect(pp, cs, cp, openDataAfter);
        }));
        dialog.show();
    }

    private EditText numberField(String hint) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_NUMBER);
        field.setPadding(0, dp(10), 0, dp(10));
        return field;
    }

    private void pairAndConnect(int pairPort, String code, Integer connectPort, boolean openDataAfter) {
        showBusy("正在配对无线调试…");
        io.submit(() -> {
            try {
                AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(this);
                if (manager.isConnected()) manager.disconnect();
                String host = AndroidUtils.getHostIpAddress(this);
                manager.pair(host, pairPort, code);
                boolean ok;
                if (connectPort != null) ok = manager.connect(host, connectPort);
                else ok = manager.autoConnect(this, 8000);
                if (!ok && !manager.isConnected()) throw new IllegalStateException("配对成功，但连接端口未找到。可重新授权并填写无线调试主页面显示的连接端口。 ");
                ShellExecutor.run(this, "printf WDM_OK");
                runOnUiThread(() -> {
                    hideBusy();
                    refreshAccessState();
                    toast("Android/data 已解锁");
                    if (openDataAfter) openPath(DATA);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> { hideBusy(); showError("无线调试连接失败", readableError(e)); refreshAccessState(); });
            }
        });
    }

    private void attemptAutoConnect() {
        io.submit(() -> {
            try {
                AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(this);
                if (!manager.isConnected()) manager.autoConnect(this, 2500);
            } catch (Throwable ignored) {}
            runOnUiThread(this::refreshAccessState);
        });
    }

    private void manualReconnect(boolean openDataAfter) {
        showBusy("正在重新连接…");
        io.submit(() -> {
            try {
                AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(this);
                if (!manager.isConnected()) manager.autoConnect(this, 8000);
                if (!manager.isConnected()) throw new IllegalStateException("没有发现无线调试连接端口，请确认无线调试已开启");
                ShellExecutor.run(this, "printf WDM_OK");
                runOnUiThread(() -> {
                    hideBusy();
                    refreshAccessState();
                    toast("已重新连接");
                    if (openDataAfter) openPath(DATA);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> { hideBusy(); showError("自动重连失败", readableError(e)); refreshAccessState(); });
            }
        });
    }

    private void disconnectAdb() {
        io.submit(() -> {
            try { AdbConnectionManager.getInstance(this).disconnect(); } catch (Throwable ignored) {}
            runOnUiThread(() -> { refreshAccessState(); if (FileOps.isRestricted(currentPath)) showHome(); });
        });
    }

    private void openDeveloperSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Throwable e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void updateSelectionUi() {
        int count = adapter.selectedCount();
        selectionBar.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
        if (count > 0) {
            toolbar.setTitle("已选择 " + count + " 项");
            toolbar.setSubtitle(currentPath);
        } else {
            toolbar.setTitle(FileOps.isRestricted(currentPath) ? "Android/data" : "文件");
            toolbar.setSubtitle(FileOps.isRestricted(currentPath) ? "无线调试权限" : "本机权限");
        }
    }

    private void clearSelection() {
        adapter.clearSelection();
        updateSelectionUi();
    }

    private void setClipboard(boolean move) {
        List<String> selected = adapter.selectedPaths();
        if (selected.isEmpty()) return;
        clipboard.clear();
        clipboard.addAll(selected);
        clipboardMove = move;
        clearSelection();
        clipboardBar.setVisibility(View.VISIBLE);
        clipboardText.setText((move ? "移动" : "复制") + " " + clipboard.size() + " 项到…");
        toast("进入目标文件夹后点“粘贴”");
    }

    private void clearClipboard() {
        clipboard.clear();
        clipboardBar.setVisibility(View.GONE);
    }

    private void pasteClipboard() {
        if (clipboard.isEmpty()) return;
        boolean needShell = FileOps.isRestricted(currentPath);
        for (String src : clipboard) needShell |= FileOps.isRestricted(src);
        if (needShell && !ShellExecutor.isConnected(this)) { showUnlockDialog(false); return; }
        List<String> sources = new ArrayList<>(clipboard);
        boolean move = clipboardMove;
        showOperationProgress(move ? "正在移动…" : "正在复制…", callback -> FileOps.copy(this, sources, currentPath, move, callback), () -> {
            if (move) clearClipboard();
            refreshCurrent();
        });
    }

    private void confirmDeleteSelected() {
        List<String> paths = adapter.selectedPaths();
        if (paths.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("删除 " + paths.size() + " 项？")
                .setMessage("此操作无法从本应用中撤销。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> showOperationProgress("正在删除…", callback -> FileOps.delete(this, paths, callback), () -> { clearSelection(); refreshCurrent(); }))
                .show();
    }

    private void openFile(FileEntry entry) {
        try {
            java.io.File file = new java.io.File(entry.path);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
            String ext = MimeTypeMap.getFileExtensionFromUrl(file.getName());
            String mime = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
            if (mime == null) mime = "*/*";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "打开 " + entry.name));
        } catch (Throwable e) {
            showFileActions(entry);
        }
    }

    private void showSelectedMore() {
        List<String> selected = adapter.selectedPaths();
        if (selected.isEmpty()) return;
        if (selected.size() == 1) {
            String path = selected.get(0);
            String[] actions = new String[]{"重命名", "复制路径", "收藏所在目录"};
            new AlertDialog.Builder(this).setTitle(FileOps.name(path)).setItems(actions, (d, which) -> {
                if (which == 0) {
                    FileEntry target = null;
                    for (FileEntry e : allFiles) if (e.path.equals(path)) { target = e; break; }
                    if (target != null) { clearSelection(); showRename(target); }
                } else if (which == 1) {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("path", path));
                    toast("路径已复制");
                } else addFavorite(FileOps.parent(path));
            }).show();
        } else {
            new AlertDialog.Builder(this).setTitle("已选择 " + selected.size() + " 项")
                    .setItems(new String[]{"复制所有路径", "收藏当前目录"}, (d, which) -> {
                        if (which == 0) {
                            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("paths", android.text.TextUtils.join("\n", selected)));
                            toast("路径已复制");
                        } else addFavorite(currentPath);
                    }).show();
        }
    }

    private void showFileActions(FileEntry entry) {
        String[] actions = new String[]{"复制", "移动", "重命名", "删除"};
        new AlertDialog.Builder(this).setTitle(entry.name).setItems(actions, (d, which) -> {
            if (which == 0 || which == 1) {
                clipboard.clear(); clipboard.add(entry.path); clipboardMove = which == 1;
                clipboardBar.setVisibility(View.VISIBLE);
                clipboardText.setText((clipboardMove ? "移动" : "复制") + " 1 项到…");
            } else if (which == 2) showRename(entry);
            else confirmDelete(Collections.singletonList(entry.path));
        }).show();
    }

    private void confirmDelete(List<String> paths) {
        new AlertDialog.Builder(this).setTitle("确定删除？").setMessage(FileOps.name(paths.get(0)))
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> showOperationProgress("正在删除…", cb -> FileOps.delete(this, paths, cb), this::refreshCurrent)).show();
    }

    private void showRename(FileEntry entry) {
        EditText input = new EditText(this);
        input.setText(entry.name);
        input.setSelectAllOnFocus(true);
        int p = dp(20); input.setPadding(p, p, p, p);
        new AlertDialog.Builder(this).setTitle("重命名").setView(input).setNegativeButton("取消", null)
                .setPositiveButton("确定", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty() || name.contains("/")) { toast("名称无效"); return; }
                    runSimpleOperation("正在重命名…", () -> FileOps.rename(this, entry.path, name));
                }).show();
    }

    private void showCreateFolder() {
        if (homeView.getVisibility() == View.VISIBLE) return;
        EditText input = new EditText(this);
        input.setHint("文件夹名称");
        int p = dp(20); input.setPadding(p, p, p, p);
        new AlertDialog.Builder(this).setTitle("新建文件夹").setView(input).setNegativeButton("取消", null)
                .setPositiveButton("创建", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty() || name.contains("/")) { toast("名称无效"); return; }
                    runSimpleOperation("正在创建…", () -> FileOps.mkdir(this, currentPath, name));
                }).show();
    }

    private void runSimpleOperation(String title, ThrowingRunnable task) {
        showBusy(title);
        io.submit(() -> {
            try {
                task.run();
                runOnUiThread(() -> { hideBusy(); refreshCurrent(); });
            } catch (Throwable e) {
                runOnUiThread(() -> { hideBusy(); showError("操作失败", readableError(e)); });
            }
        });
    }

    private interface Operation { void run(FileOps.ProgressCallback callback) throws Exception; }
    private interface ThrowingRunnable { void run() throws Exception; }

    private void showOperationProgress(String title, Operation operation, Runnable done) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(12), dp(22), dp(18));
        TextView message = new TextView(this); message.setText("准备中…");
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setProgress(0);
        box.addView(message); box.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(box).setCancelable(false).create();
        dialog.show();

        io.submit(() -> {
            try {
                operation.run((finished, total, current) -> runOnUiThread(() -> {
                    int pct = total <= 0 ? 0 : Math.min(100, finished * 100 / total);
                    bar.setProgress(pct);
                    message.setText(current == null || current.isEmpty() ? "正在完成…" : current);
                }));
                runOnUiThread(() -> { dialog.dismiss(); done.run(); });
            } catch (Throwable e) {
                runOnUiThread(() -> { dialog.dismiss(); showError("操作失败", readableError(e)); });
            }
        });
    }

    private void showPathMenu() {
        String[] items = new String[]{"复制路径", "收藏当前路径", "排序", showHidden ? "隐藏隐藏文件" : "显示隐藏文件"};
        new AlertDialog.Builder(this).setTitle(currentPath).setItems(items, (d, which) -> {
            if (which == 0) {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("path", currentPath));
                toast("路径已复制");
            } else if (which == 1) addFavorite(currentPath);
            else if (which == 2) showSortDialog();
            else { showHidden = !showHidden; prefs.edit().putBoolean("show_hidden", showHidden).apply(); refreshCurrent(); }
        }).show();
    }

    private void showSortDialog() {
        String[] labels = new String[]{"名称", "修改时间", "大小", "类型"};
        new AlertDialog.Builder(this).setTitle("排序方式").setSingleChoiceItems(labels, sortMode, (dialog, which) -> {
            sortMode = which; dialog.dismiss(); showSortDirection();
        }).show();
    }

    private void showSortDirection() {
        new AlertDialog.Builder(this).setTitle("排序方向").setItems(new String[]{"升序", "降序"}, (d, which) -> {
            sortDescending = which == 1; applyFilterAndSort();
        }).show();
    }

    private void addFavorite(String path) {
        Set<String> set = getFavorites();
        set.add(path);
        prefs.edit().putStringSet("favorites", set).apply();
        refreshAccessState();
        toast("已收藏");
    }

    private Set<String> getFavorites() {
        return new HashSet<>(prefs.getStringSet("favorites", Collections.emptySet()));
    }

    private void showFavorites() {
        List<String> items = new ArrayList<>(getFavorites());
        Collections.sort(items);
        if (items.isEmpty()) { toast("还没有收藏路径"); return; }
        new AlertDialog.Builder(this).setTitle("收藏").setItems(items.toArray(new String[0]), (d, which) -> openPath(items.get(which)))
                .setNeutralButton("管理", (d, w) -> manageFavorites(items)).show();
    }

    private void manageFavorites(List<String> items) {
        boolean[] checked = new boolean[items.size()];
        new AlertDialog.Builder(this).setTitle("选择要删除的收藏").setMultiChoiceItems(items.toArray(new String[0]), checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("取消", null).setPositiveButton("删除", (d, w) -> {
                    Set<String> set = getFavorites();
                    for (int i = 0; i < checked.length; i++) if (checked[i]) set.remove(items.get(i));
                    prefs.edit().putStringSet("favorites", set).apply(); refreshAccessState();
                }).show();
    }

    private void showSettingsMenu() {
        boolean shell = ShellExecutor.isConnected(this);
        String[] items = new String[]{
                FileOps.hasAllFilesAccess() ? "普通文件权限：已开启" : "开启普通文件访问权限",
                shell ? "Android/data：已解锁" : "无线调试授权 Android/data",
                "打开开发者/无线调试设置",
                shell ? "断开无线调试" : "尝试自动重连",
                showHidden ? "隐藏隐藏文件" : "显示隐藏文件",
                "关于"
        };
        new AlertDialog.Builder(this).setTitle("设置").setItems(items, (d, which) -> {
            if (which == 0) openAllFilesSettings();
            else if (which == 1) { if (shell) openPath(DATA); else showUnlockDialog(false); }
            else if (which == 2) openDeveloperSettings();
            else if (which == 3) { if (shell) disconnectAdb(); else attemptAutoConnect(); }
            else if (which == 4) { showHidden = !showHidden; prefs.edit().putBoolean("show_hidden", showHidden).apply(); if (fileView.getVisibility() == View.VISIBLE) refreshCurrent(); }
            else new AlertDialog.Builder(this).setTitle("无线文件管理器 v0.3").setMessage("普通目录使用系统文件权限；Android/data 与 Android/obb 仅在无线调试授权有效时使用 shell 权限。关闭开发者选项或无线调试后，Data 权限可能立即失效；重新打开无线调试后可尝试自动重连。 ").setPositiveButton("知道了", null).show();
        }).show();
    }

    private AlertDialog busyDialog;
    private void showBusy(String message) {
        runOnUiThread(() -> {
            if (busyDialog != null && busyDialog.isShowing()) busyDialog.dismiss();
            ProgressBar bar = new ProgressBar(this);
            FrameLayout frame = new FrameLayout(this); frame.setPadding(dp(28), dp(14), dp(28), dp(14)); frame.addView(bar);
            busyDialog = new AlertDialog.Builder(this).setTitle(message).setView(frame).setCancelable(false).create();
            busyDialog.show();
        });
    }
    private void hideBusy() { if (busyDialog != null && busyDialog.isShowing()) busyDialog.dismiss(); }

    private void showError(String title, String message) { new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("确定", null).show(); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private static String extension(String name) { int i = name.lastIndexOf('.'); return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT); }
    private static String readableError(Throwable e) {
        Throwable t = e; while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        String m = t.getMessage(); if (m == null || m.trim().isEmpty()) m = t.getClass().getSimpleName();
        if (m.toLowerCase(Locale.ROOT).contains("permission denied")) return "没有权限访问此位置。若这是 Android/data，请重新连接无线调试。";
        if (m.toLowerCase(Locale.ROOT).contains("stream closed")) return "无线调试 Shell 已断开，请重新连接。";
        return m.replace('\n', ' ').trim();
    }
}
