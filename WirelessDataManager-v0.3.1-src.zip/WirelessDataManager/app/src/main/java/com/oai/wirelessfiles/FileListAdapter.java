package com.oai.wirelessfiles;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.Holder> {
    public interface Listener {
        void onClick(FileEntry entry);
        void onLongClick(FileEntry entry);
    }

    private final Listener listener;
    private final List<FileEntry> items = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();

    public FileListAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<FileEntry> next) {
        items.clear();
        items.addAll(next);
        Set<String> valid = new HashSet<>();
        for (FileEntry e : next) valid.add(e.path);
        selected.retainAll(valid);
        notifyDataSetChanged();
    }

    public void toggle(FileEntry entry) {
        if (!selected.add(entry.path)) selected.remove(entry.path);
        notifyDataSetChanged();
    }

    public void clearSelection() {
        if (selected.isEmpty()) return;
        selected.clear();
        notifyDataSetChanged();
    }

    public int selectedCount() { return selected.size(); }
    public boolean isSelected(FileEntry entry) { return selected.contains(entry.path); }

    public List<String> selectedPaths() {
        return new ArrayList<>(selected);
    }

    @Override public long getItemId(int position) { return items.get(position).path.hashCode(); }
    @Override public int getItemCount() { return items.size(); }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_file, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        FileEntry e = items.get(position);
        boolean checked = selected.contains(e.path);
        h.check.setVisibility(selected.isEmpty() ? View.GONE : View.VISIBLE);
        h.check.setChecked(checked);
        h.icon.setText(iconFor(e));
        h.name.setText(e.name);
        h.name.setTypeface(null, e.directory ? Typeface.BOLD : Typeface.NORMAL);
        String meta = e.directory ? "文件夹" : human(e.size);
        if (e.modified > 0) meta += "  ·  " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(e.modified);
        h.meta.setText(meta);
        h.itemView.setActivated(checked);
        h.itemView.setOnClickListener(v -> listener.onClick(e));
        h.itemView.setOnLongClickListener(v -> { listener.onLongClick(e); return true; });
    }

    private static String iconFor(FileEntry e) {
        if (e.directory) return "📁";
        String n = e.name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".apk")) return "📦";
        if (n.endsWith(".zip") || n.endsWith(".7z") || n.endsWith(".rar") || n.endsWith(".tar") || n.endsWith(".gz")) return "🗜️";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".gif")) return "🖼️";
        if (n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".mov")) return "🎬";
        if (n.endsWith(".mp3") || n.endsWith(".flac") || n.endsWith(".wav") || n.endsWith(".m4a")) return "🎵";
        if (n.endsWith(".txt") || n.endsWith(".log") || n.endsWith(".json") || n.endsWith(".xml") || n.endsWith(".ini") || n.endsWith(".cfg") || n.endsWith(".sh")) return "📝";
        if (n.endsWith(".pdf")) return "📕";
        return "📄";
    }

    private static String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024L * 1024) return String.format(Locale.getDefault(), "%.1f KB", n / 1024.0);
        if (n < 1024L * 1024 * 1024) return String.format(Locale.getDefault(), "%.1f MB", n / 1048576.0);
        return String.format(Locale.getDefault(), "%.1f GB", n / 1073741824.0);
    }

    static class Holder extends RecyclerView.ViewHolder {
        final CheckBox check;
        final TextView icon, name, meta;
        Holder(@NonNull View v) {
            super(v);
            check = v.findViewById(R.id.rowCheck);
            icon = v.findViewById(R.id.rowIcon);
            name = v.findViewById(R.id.rowName);
            meta = v.findViewById(R.id.rowMeta);
        }
    }
}
