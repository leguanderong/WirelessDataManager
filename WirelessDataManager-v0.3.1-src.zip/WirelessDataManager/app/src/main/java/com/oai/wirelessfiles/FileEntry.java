package com.oai.wirelessfiles;

public class FileEntry {
    public final String name;
    public final String path;
    public final boolean directory;
    public final long size;
    public final long modified;

    public FileEntry(String name, String path, boolean directory, long size, long modified) {
        this.name = name;
        this.path = path;
        this.directory = directory;
        this.size = size;
        this.modified = modified;
    }
}
